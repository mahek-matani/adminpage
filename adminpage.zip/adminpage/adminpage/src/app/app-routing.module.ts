import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewTransactionComponent } from './view-transaction/view-transaction.component';
import { ApproveTransactionComponent } from './approve-transaction/approve-transaction.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { DeleteAccountComponent } from './delete-account/delete-account.component';
import { UserComponent } from './user/user.component';


const routes: Routes = [
  {path: 'approve-transaction', component: ApproveTransactionComponent},
  {path: 'create-account', component: CreateAccountComponent},
  {path: 'delete-account', component: DeleteAccountComponent},
  {path: 'user', component: UserComponent},
  {path: 'view-transaction', component: ViewTransactionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [ViewTransactionComponent, ApproveTransactionComponent, CreateAccountComponent, DeleteAccountComponent, UserComponent];